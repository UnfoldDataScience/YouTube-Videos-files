# 1. Imports and Initialization
from typing import Any
import httpx
from mcp.server.fastmcp import FastMCP

# Initialize FastMCP server
mcp = FastMCP("weather")
if __name__ == "__main__":
    # Initialize and run the server
    print(" MCP Server starting...", flush=True)
    try:
        mcp.run(transport="stdio")
    except Exception as e:
        print(f"MCP server failed: {e}", flush=True)
    